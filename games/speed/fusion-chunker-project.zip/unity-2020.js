(() => {
    var n = {
            56: (n, e, t) => {
                "use strict";
                n.exports = function (n) {
                    var e = t.nc;
                    e && n.setAttribute("nonce", e);
                };
            },
            72: (n) => {
                "use strict";
                var e = [];
                function t(n) {
                    for (var t = -1, i = 0; i < e.length; i++)
                        if (e[i].identifier === n) {
                            t = i;
                            break;
                        }
                    return t;
                }
                function i(n, i) {
                    for (var r = {}, a = [], s = 0; s < n.length; s++) {
                        var l = n[s],
                            d = i.base ? l[0] + i.base : l[0],
                            c = r[d] || 0,
                            h = "".concat(d, " ").concat(c);
                        r[d] = c + 1;
                        var u = t(h),
                            m = { css: l[1], media: l[2], sourceMap: l[3], supports: l[4], layer: l[5] };
                        if (-1 !== u) e[u].references++, e[u].updater(m);
                        else {
                            var f = o(m, i);
                            (i.byIndex = s), e.splice(s, 0, { identifier: h, updater: f, references: 1 });
                        }
                        a.push(h);
                    }
                    return a;
                }
                function o(n, e) {
                    var t = e.domAPI(e);
                    t.update(n);
                    return function (e) {
                        if (e) {
                            if (
                                e.css === n.css &&
                                e.media === n.media &&
                                e.sourceMap === n.sourceMap &&
                                e.supports === n.supports &&
                                e.layer === n.layer
                            )
                                return;
                            t.update((n = e));
                        } else t.remove();
                    };
                }
                n.exports = function (n, o) {
                    var r = i((n = n || []), (o = o || {}));
                    return function (n) {
                        n = n || [];
                        for (var a = 0; a < r.length; a++) {
                            var s = t(r[a]);
                            e[s].references--;
                        }
                        for (var l = i(n, o), d = 0; d < r.length; d++) {
                            var c = t(r[d]);
                            0 === e[c].references && (e[c].updater(), e.splice(c, 1));
                        }
                        r = l;
                    };
                };
            },
            113: (n) => {
                "use strict";
                n.exports = function (n, e) {
                    if (e.styleSheet) e.styleSheet.cssText = n;
                    else {
                        for (; e.firstChild; ) e.removeChild(e.firstChild);
                        e.appendChild(document.createTextNode(n));
                    }
                };
            },
            314: (n) => {
                "use strict";
                n.exports = function (n) {
                    var e = [];
                    return (
                        (e.toString = function () {
                            return this.map(function (e) {
                                var t = "",
                                    i = void 0 !== e[5];
                                return (
                                    e[4] && (t += "@supports (".concat(e[4], ") {")),
                                    e[2] && (t += "@media ".concat(e[2], " {")),
                                    i && (t += "@layer".concat(e[5].length > 0 ? " ".concat(e[5]) : "", " {")),
                                    (t += n(e)),
                                    i && (t += "}"),
                                    e[2] && (t += "}"),
                                    e[4] && (t += "}"),
                                    t
                                );
                            }).join("");
                        }),
                        (e.i = function (n, t, i, o, r) {
                            "string" == typeof n && (n = [[null, n, void 0]]);
                            var a = {};
                            if (i)
                                for (var s = 0; s < this.length; s++) {
                                    var l = this[s][0];
                                    null != l && (a[l] = !0);
                                }
                            for (var d = 0; d < n.length; d++) {
                                var c = [].concat(n[d]);
                                (i && a[c[0]]) ||
                                    (void 0 !== r &&
                                        (void 0 === c[5] ||
                                            (c[1] = "@layer"
                                                .concat(c[5].length > 0 ? " ".concat(c[5]) : "", " {")
                                                .concat(c[1], "}")),
                                        (c[5] = r)),
                                    t &&
                                        (c[2]
                                            ? ((c[1] = "@media ".concat(c[2], " {").concat(c[1], "}")), (c[2] = t))
                                            : (c[2] = t)),
                                    o &&
                                        (c[4]
                                            ? ((c[1] = "@supports (".concat(c[4], ") {").concat(c[1], "}")), (c[4] = o))
                                            : (c[4] = "".concat(o))),
                                    e.push(c));
                            }
                        }),
                        e
                    );
                };
            },
            446: (n, e, t) => {
                var i =
                        (function () {
                            return this;
                        })() || Function("return this")(),
                    o = i.regeneratorRuntime && Object.getOwnPropertyNames(i).indexOf("regeneratorRuntime") >= 0,
                    r = o && i.regeneratorRuntime;
                if (((i.regeneratorRuntime = void 0), t(989), o)) i.regeneratorRuntime = r;
                else
                    try {
                        delete i.regeneratorRuntime;
                    } catch (n) {
                        i.regeneratorRuntime = void 0;
                    }
            },
            540: (n) => {
                "use strict";
                n.exports = function (n) {
                    var e = document.createElement("style");
                    return n.setAttributes(e, n.attributes), n.insert(e, n.options), e;
                };
            },
            601: (n) => {
                "use strict";
                n.exports = function (n) {
                    return n[1];
                };
            },
            612: () => {
                let n;
                (window.initPokiBridge = function (e) {
                    (n = e),
                        window.unityGame
                            ? window.pokiReady || window.pokiAdBlock
                                ? window.pokiReady
                                    ? window.unityGame.SendMessage(e, "ready")
                                    : window.pokiAdBlock && window.unityGame.SendMessage(e, "adblock")
                                : (window.pokiBridge = e)
                            : setTimeout(() => {
                                  window.initPokiBridge(e);
                              }, 100);
                }),
                    (window.commercialBreak = () => {
                        PokiSDK.commercialBreak().then(() => {
                            window.unityGame.SendMessage(n, "commercialBreakCompleted");
                        });
                    }),
                    (window.rewardedBreak = (...e) => {
                        PokiSDK.rewardedBreak(...e).then((e) => {
                            window.unityGame.SendMessage(n, "rewardedBreakCompleted", e.toString());
                        });
                    }),
                    (window.shareableURL = (e) => {
                        PokiSDK.shareableURL(e)
                            .then((e) => {
                                window.unityGame.SendMessage(n, "shareableURLResolved", e);
                            })
                            .catch(() => {
                                window.unityGame.SendMessage(n, "shareableURLRejected");
                            });
                    });
            },
            659: (n) => {
                "use strict";
                var e = {};
                n.exports = function (n, t) {
                    var i = (function (n) {
                        if (void 0 === e[n]) {
                            var t = document.querySelector(n);
                            if (window.HTMLIFrameElement && t instanceof window.HTMLIFrameElement)
                                try {
                                    t = t.contentDocument.head;
                                } catch (n) {
                                    t = null;
                                }
                            e[n] = t;
                        }
                        return e[n];
                    })(n);
                    if (!i)
                        throw new Error(
                            "Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid."
                        );
                    i.appendChild(t);
                };
            },
            825: (n) => {
                "use strict";
                n.exports = function (n) {
                    if ("undefined" == typeof document) return { update: function () {}, remove: function () {} };
                    var e = n.insertStyleElement(n);
                    return {
                        update: function (t) {
                            !(function (n, e, t) {
                                var i = "";
                                t.supports && (i += "@supports (".concat(t.supports, ") {")),
                                    t.media && (i += "@media ".concat(t.media, " {"));
                                var o = void 0 !== t.layer;
                                o && (i += "@layer".concat(t.layer.length > 0 ? " ".concat(t.layer) : "", " {")),
                                    (i += t.css),
                                    o && (i += "}"),
                                    t.media && (i += "}"),
                                    t.supports && (i += "}");
                                var r = t.sourceMap;
                                r &&
                                    "undefined" != typeof btoa &&
                                    (i += "\n/*# sourceMappingURL=data:application/json;base64,".concat(
                                        btoa(unescape(encodeURIComponent(JSON.stringify(r)))),
                                        " */"
                                    )),
                                    e.styleTagTransform(i, n, e.options);
                            })(e, n, t);
                        },
                        remove: function () {
                            !(function (n) {
                                if (null === n.parentNode) return !1;
                                n.parentNode.removeChild(n);
                            })(e);
                        },
                    };
                };
            },
            915: (n, e, t) => {
                "use strict";
                t.d(e, { A: () => s });
                var i = t(601),
                    o = t.n(i),
                    r = t(314),
                    a = t.n(r)()(o());
                a.push([
                    n.id,
                    "* {\n    margin: 0;\n    padding: 0;\n}\n\nhtml,\nbody {\n    width: 100vw;\n    height: 100vh;\n    overflow: hidden;\n    background: #002B50;\n    font-family: Torus, Arial, Helvetica, sans-serif;\n    color: #fff;\n}\n\n#game-container {\n    position: absolute !important;\n    left: 50%;\n    top: 50%;\n    display: none;\n}\n\n#game,\n#game canvas {\n    width: 100%;\n    height: 100%;\n}\n\n#loader {\n    width: 100%;\n    height: 100%;\n}\n\n/**\n   * Slideshow\n   */\n\n#slideshow {\n    width: 100%;\n    height: 100%;\n    flex-direction: column;\n    align-items: center;\n    justify-content: space-evenly;\n    display: flex;\n    user-select: none;\n}\n\n@font-face {\n    font-family: Torus;\n    src:\n        url('//a.poki-cdn.com/fonts/torus-bold-webfont.woff2') format('woff2'),\n        url('//a.poki-cdn.com/fonts/torus-bold-webfont.woff') format('woff');\n    font-style: bold;\n    font-weight: 700;\n}\n\n/**\n   * Slideshow - Top section\n   */\n#progress-spinner{\n    margin-left: 0;\n    margin-top: 0;\n    left: 0px;\n    display:none;\n    transform: translate(100%, -50%);\n    width:10vh;\n}\n#progress-spinner >div{\n    width:2vh;\n    height:2vh;\n}\n#thumbnail {\n    box-shadow: 0 1vh 2vh rgba(0, 0, 0, 0.4);\n    /* box-shadow: 0 6px 12px rgba(0, 0, 0, 0.24); */\n    border-radius: 16.667%;\n}\n\n#slideshow-top {\n    display: flex;\n    margin: 2.5vh 0;\n}\n\n#slideshow-top-container {\n    display: flex;\n    flex-direction: column;\n    justify-content: center;\n    flex-grow: 1;\n}\n\n#game-title, #progress-comment {\n    display: flex;\n    flex-grow: 1;\n    align-items: center;\n    font-size:2vh;\n}\n\n#progress-container {\n    display: flex;\n    align-items: center;\n    flex-grow: 1;\n    transition: 0.2s ease-out all;\n}\n\n#progress-container.done {\n    opacity: 0;\n}\n\n#progress-bar {\n    background: #fff;\n    width: 100%;\n    overflow: hidden;\n}\n\n#progress-fill {\n    background: #3CF7DC;\n    height: 100%;\n    transition: 0.2s ease-out all;\n    animation-name: fillColor;\n    animation-duration: 3.5s;\n    animation-iteration-count: infinite;\n    animation-fill-mode: both;\n}\n\n@keyframes fillColor {\n    0% {\n        background-color: #3CF7DC;\n    }\n\n    25% {\n        background-color: #FFA9BE;\n    }\n\n    50% {\n        background-color: #FFDC00;\n    }\n\n    75% {\n        background-color: #E0AEF5;\n    }\n\n    100% {\n        background-color: #3CF7DC;\n    }\n}\n\n@media (orientation: portrait) {\n    #thumbnail {\n        margin-right: 2.4vh;\n    }\n\n    #game-title h1 {\n        font-size: 2vh;\n    }\n\n    #slideshow-top {\n        width: 70vw;\n    }\n\n    #progress-bar {\n        height: 1vh;\n        border-radius: 0.5vh;\n    }\n\n    #progress-fill {\n        border-radius: 0.5vh;\n    }\n\n    #thumbnail {\n        width: 5vh;\n        height: 5vh;\n    }\n\n    #progress-amount {\n        font-size: 2vh;\n        margin-left: 1.5vh;\n        width: 3vh;\n    }\n}\n\n@media (orientation: landscape) {\n    #thumbnail {\n        margin-right: 3vh;\n    }\n\n    #game-title h1 {\n        font-size: 3vh;\n    }\n\n    #slideshow-top {\n        width: 50vw;\n    }\n\n    #progress-bar {\n        height: 1.2vh;\n        border-radius: 0.6vh;\n    }\n\n    #progress-fill {\n        border-radius: 0.6vh;\n    }\n\n    #thumbnail {\n        width: 7.5vh;\n        height: 7.5vh;\n    }\n\n    #progress-amount {\n        font-size: 2.5vh;\n        margin-left: 1.875vh;\n        width: 3.75vh;\n    }\n}\n\n/**\n   * Slideshow - Images section\n   */\n\n#slideshow-images {\n    width: 100vw;\n    display: flex;\n    justify-content: center;\n}\n\n#slideshow-images .image {\n    position: absolute;\n    box-shadow: 0 2.4vh 3.6vh rgba(0, 0, 0, 0.4);\n    transition-property: transform;\n    transition-timing-function: ease-in-out;\n    perspective: 1000px;\n    left: 0;\n    overflow: hidden;\n    /* border: 1vh solid; */\n}\n\n#slideshow-images .image img {\n    width: 100%;\n    height: 100%;\n}\n\n#slideshow-images .image:nth-of-type(1n) {\n    border-color: #3BE8B0;\n}\n\n#slideshow-images .image:nth-of-type(2n) {\n    border-color: #FF6D92;\n}\n\n#slideshow-images .image:nth-of-type(3n) {\n    border-color: #A177FF;\n}\n\n#slideshow-images .image:nth-of-type(4n) {\n    border-color: #FFD200;\n}\n\n#slideshow-images .left {\n    z-index: 2;\n}\n#slideshow-images .right {\n    z-index: 1;\n}\n\n#slideshow-images .middle {\n    z-index: 3;\n}\n\n#slideshow-images .left img,\n#slideshow-images .right img {\n    transform: scale(1.05);\n}\n\n#slideshow-images .left img,\n#slideshow-images .right img,\n#slideshow-images .fromLeft img,\n#slideshow-images .fromRight img {\n    filter: blur(1vh);\n}\n\n#slideshow-images .inactive {\n    display: none;\n}\n\n#slideshow-images .inactive.fromLeft,\n#slideshow-images .inactive.fromRight {\n    display: block;\n}\n\n/**\n   * Slideshow - Navigation section\n   */\n\n#slideshow-nav {\n    display: flex;\n    justify-content: center;\n    margin: 2.5vh 0;\n}\n\n#slideshow-nav .bullet {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n}\n\n#slideshow-nav .bullet:after {\n    content: '';\n    background: #fff;\n    border-radius: 0.4vh;\n    width: 0.8vh;\n    height: 0.8vh;\n}\n\n#slideshow-nav .bullet.active:after {\n    background: #009CFF;\n}\n\n#slideshow-nav .bullet {\n    width: 2.5vh;\n    height: 2.5vh;\n}\n\n#slideshow-nav .bullet:after {\n    border-radius: 50%;\n    width: 50%;\n    height: 50%;\n}\n\n/**\n   * Pop-in animation\n   */\n\n#slideshow-nav,\n#slideshow-images {\n    opacity: 0;\n    transition: 0.4s all ease-out;\n    transform: translateY(2vh);\n    perspective: 1000px;\n    transition-delay: 400ms;\n}\n\n#slideshow-nav {\n    transition-delay: 600ms;\n}\n\n#slideshow.active #slideshow-images,\n#slideshow.active #slideshow-nav {\n    opacity: 1;\n    transform: translateY(0);\n}\n\n@keyframes bounceInDown {\n\n    from,\n    60%,\n    75%,\n    90%,\n    to {\n        animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);\n    }\n\n    0% {\n        transform: translate3d(0, -100vh, 0);\n    }\n\n    40% {\n        transform: translate3d(0, 0.5vh, 0);\n    }\n\n    65% {\n        transform: translate3d(0, -0.2vh, 0);\n    }\n\n    80% {\n        transform: translate3d(0, 0.1vh, 0);\n    }\n\n    to {\n        transform: translate3d(0, 0, 0);\n    }\n}\n\n#slideshow-top {\n    transform: translate3d(0, -20vh, 0);\n    opacity: 0;\n}\n\n#slideshow-top.active {\n    opacity: 1;\n    transform: translate3d(0, 0, 0);\n    animation-name: bounceInDown;\n    animation-duration: 0.5s;\n}\n\n/**\n   * Loading dots\n   */\n.spinner {\n    position: relative;\n    left: -9999px;\n    animation: dot-pulse 1.5s infinite linear;\n    animation-delay: .25s;\n    transform:translate(50vw, 50vh) translate(-130%, -130%);\n  }\n\n  .spinner:before, .spinner:after {\n    content: '';\n    display: inline-block;\n    position: absolute;\n    top: 0;\n    width: 10px;\n    height: 10px;\n    border-radius: 5px;\n  }\n  .spinner, .spinner:before, .spinner:after{\n    width: 10px;\n    height: 10px;\n    border-radius: 5px;\n  }\n\n  .spinner:before {\n    animation: dot-pulse 1.5s infinite linear;\n    animation-delay: 0s;\n    left:-20px;\n  }\n\n  .spinner:after {\n    animation: dot-pulse 1.5s infinite linear;\n    animation-delay: .5s;\n    left:20px;\n  }\n\n  @keyframes dot-pulse {\n    0% {\n      box-shadow: 9999px 0 0 -5px #FFF;\n    }\n    30% {\n      box-shadow: 9999px 0 0 2px #FFF;\n    }\n    60%,\n    100% {\n      box-shadow: 9999px 0 0 -5px #FFF;\n    }\n  }\n",
                    "",
                ]);
                const s = a;
            },
            989: (n) => {
                !(function (e) {
                    "use strict";
                    var t,
                        i = Object.prototype,
                        o = i.hasOwnProperty,
                        r = "function" == typeof Symbol ? Symbol : {},
                        a = r.iterator || "@@iterator",
                        s = r.asyncIterator || "@@asyncIterator",
                        l = r.toStringTag || "@@toStringTag",
                        d = e.regeneratorRuntime;
                    if (d) n.exports = d;
                    else {
                        (d = e.regeneratorRuntime = n.exports).wrap = y;
                        var c = "suspendedStart",
                            h = "suspendedYield",
                            u = "executing",
                            m = "completed",
                            f = {},
                            p = {};
                        p[a] = function () {
                            return this;
                        };
                        var g = Object.getPrototypeOf,
                            w = g && g(g(F([])));
                        w && w !== i && o.call(w, a) && (p = w);
                        var v = (k.prototype = x.prototype = Object.create(p));
                        (S.prototype = v.constructor = k),
                            (k.constructor = S),
                            (k[l] = S.displayName = "GeneratorFunction"),
                            (d.isGeneratorFunction = function (n) {
                                var e = "function" == typeof n && n.constructor;
                                return !!e && (e === S || "GeneratorFunction" === (e.displayName || e.name));
                            }),
                            (d.mark = function (n) {
                                return (
                                    Object.setPrototypeOf
                                        ? Object.setPrototypeOf(n, k)
                                        : ((n.__proto__ = k), l in n || (n[l] = "GeneratorFunction")),
                                    (n.prototype = Object.create(v)),
                                    n
                                );
                            }),
                            (d.awrap = function (n) {
                                return { __await: n };
                            }),
                            E(L.prototype),
                            (L.prototype[s] = function () {
                                return this;
                            }),
                            (d.AsyncIterator = L),
                            (d.async = function (n, e, t, i) {
                                var o = new L(y(n, e, t, i));
                                return d.isGeneratorFunction(e)
                                    ? o
                                    : o.next().then(function (n) {
                                          return n.done ? n.value : o.next();
                                      });
                            }),
                            E(v),
                            (v[l] = "Generator"),
                            (v[a] = function () {
                                return this;
                            }),
                            (v.toString = function () {
                                return "[object Generator]";
                            }),
                            (d.keys = function (n) {
                                var e = [];
                                for (var t in n) e.push(t);
                                return (
                                    e.reverse(),
                                    function t() {
                                        for (; e.length; ) {
                                            var i = e.pop();
                                            if (i in n) return (t.value = i), (t.done = !1), t;
                                        }
                                        return (t.done = !0), t;
                                    }
                                );
                            }),
                            (d.values = F),
                            (C.prototype = {
                                constructor: C,
                                reset: function (n) {
                                    if (
                                        ((this.prev = 0),
                                        (this.next = 0),
                                        (this.sent = this._sent = t),
                                        (this.done = !1),
                                        (this.delegate = null),
                                        (this.method = "next"),
                                        (this.arg = t),
                                        this.tryEntries.forEach(T),
                                        !n)
                                    )
                                        for (var e in this)
                                            "t" === e.charAt(0) &&
                                                o.call(this, e) &&
                                                !isNaN(+e.slice(1)) &&
                                                (this[e] = t);
                                },
                                stop: function () {
                                    this.done = !0;
                                    var n = this.tryEntries[0].completion;
                                    if ("throw" === n.type) throw n.arg;
                                    return this.rval;
                                },
                                dispatchException: function (n) {
                                    if (this.done) throw n;
                                    var e = this;
                                    function i(i, o) {
                                        return (
                                            (s.type = "throw"),
                                            (s.arg = n),
                                            (e.next = i),
                                            o && ((e.method = "next"), (e.arg = t)),
                                            !!o
                                        );
                                    }
                                    for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                                        var a = this.tryEntries[r],
                                            s = a.completion;
                                        if ("root" === a.tryLoc) return i("end");
                                        if (a.tryLoc <= this.prev) {
                                            var l = o.call(a, "catchLoc"),
                                                d = o.call(a, "finallyLoc");
                                            if (l && d) {
                                                if (this.prev < a.catchLoc) return i(a.catchLoc, !0);
                                                if (this.prev < a.finallyLoc) return i(a.finallyLoc);
                                            } else if (l) {
                                                if (this.prev < a.catchLoc) return i(a.catchLoc, !0);
                                            } else {
                                                if (!d) throw new Error("try statement without catch or finally");
                                                if (this.prev < a.finallyLoc) return i(a.finallyLoc);
                                            }
                                        }
                                    }
                                },
                                abrupt: function (n, e) {
                                    for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                        var i = this.tryEntries[t];
                                        if (
                                            i.tryLoc <= this.prev &&
                                            o.call(i, "finallyLoc") &&
                                            this.prev < i.finallyLoc
                                        ) {
                                            var r = i;
                                            break;
                                        }
                                    }
                                    r &&
                                        ("break" === n || "continue" === n) &&
                                        r.tryLoc <= e &&
                                        e <= r.finallyLoc &&
                                        (r = null);
                                    var a = r ? r.completion : {};
                                    return (
                                        (a.type = n),
                                        (a.arg = e),
                                        r ? ((this.method = "next"), (this.next = r.finallyLoc), f) : this.complete(a)
                                    );
                                },
                                complete: function (n, e) {
                                    if ("throw" === n.type) throw n.arg;
                                    return (
                                        "break" === n.type || "continue" === n.type
                                            ? (this.next = n.arg)
                                            : "return" === n.type
                                              ? ((this.rval = this.arg = n.arg),
                                                (this.method = "return"),
                                                (this.next = "end"))
                                              : "normal" === n.type && e && (this.next = e),
                                        f
                                    );
                                },
                                finish: function (n) {
                                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                        var t = this.tryEntries[e];
                                        if (t.finallyLoc === n) return this.complete(t.completion, t.afterLoc), T(t), f;
                                    }
                                },
                                catch: function (n) {
                                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                        var t = this.tryEntries[e];
                                        if (t.tryLoc === n) {
                                            var i = t.completion;
                                            if ("throw" === i.type) {
                                                var o = i.arg;
                                                T(t);
                                            }
                                            return o;
                                        }
                                    }
                                    throw new Error("illegal catch attempt");
                                },
                                delegateYield: function (n, e, i) {
                                    return (
                                        (this.delegate = { iterator: F(n), resultName: e, nextLoc: i }),
                                        "next" === this.method && (this.arg = t),
                                        f
                                    );
                                },
                            });
                    }
                    function y(n, e, t, i) {
                        var o = e && e.prototype instanceof x ? e : x,
                            r = Object.create(o.prototype),
                            a = new C(i || []);
                        return (
                            (r._invoke = (function (n, e, t) {
                                var i = c;
                                return function (o, r) {
                                    if (i === u) throw new Error("Generator is already running");
                                    if (i === m) {
                                        if ("throw" === o) throw r;
                                        return N();
                                    }
                                    for (t.method = o, t.arg = r; ; ) {
                                        var a = t.delegate;
                                        if (a) {
                                            var s = I(a, t);
                                            if (s) {
                                                if (s === f) continue;
                                                return s;
                                            }
                                        }
                                        if ("next" === t.method) t.sent = t._sent = t.arg;
                                        else if ("throw" === t.method) {
                                            if (i === c) throw ((i = m), t.arg);
                                            t.dispatchException(t.arg);
                                        } else "return" === t.method && t.abrupt("return", t.arg);
                                        i = u;
                                        var l = b(n, e, t);
                                        if ("normal" === l.type) {
                                            if (((i = t.done ? m : h), l.arg === f)) continue;
                                            return { value: l.arg, done: t.done };
                                        }
                                        "throw" === l.type && ((i = m), (t.method = "throw"), (t.arg = l.arg));
                                    }
                                };
                            })(n, t, a)),
                            r
                        );
                    }
                    function b(n, e, t) {
                        try {
                            return { type: "normal", arg: n.call(e, t) };
                        } catch (n) {
                            return { type: "throw", arg: n };
                        }
                    }
                    function x() {}
                    function S() {}
                    function k() {}
                    function E(n) {
                        ["next", "throw", "return"].forEach(function (e) {
                            n[e] = function (n) {
                                return this._invoke(e, n);
                            };
                        });
                    }
                    function L(n) {
                        function e(t, i, r, a) {
                            var s = b(n[t], n, i);
                            if ("throw" !== s.type) {
                                var l = s.arg,
                                    d = l.value;
                                return d && "object" == typeof d && o.call(d, "__await")
                                    ? Promise.resolve(d.__await).then(
                                          function (n) {
                                              e("next", n, r, a);
                                          },
                                          function (n) {
                                              e("throw", n, r, a);
                                          }
                                      )
                                    : Promise.resolve(d).then(function (n) {
                                          (l.value = n), r(l);
                                      }, a);
                            }
                            a(s.arg);
                        }
                        var t;
                        this._invoke = function (n, i) {
                            function o() {
                                return new Promise(function (t, o) {
                                    e(n, i, t, o);
                                });
                            }
                            return (t = t ? t.then(o, o) : o());
                        };
                    }
                    function I(n, e) {
                        var i = n.iterator[e.method];
                        if (i === t) {
                            if (((e.delegate = null), "throw" === e.method)) {
                                if (
                                    n.iterator.return &&
                                    ((e.method = "return"), (e.arg = t), I(n, e), "throw" === e.method)
                                )
                                    return f;
                                (e.method = "throw"),
                                    (e.arg = new TypeError("The iterator does not provide a 'throw' method"));
                            }
                            return f;
                        }
                        var o = b(i, n.iterator, e.arg);
                        if ("throw" === o.type) return (e.method = "throw"), (e.arg = o.arg), (e.delegate = null), f;
                        var r = o.arg;
                        return r
                            ? r.done
                                ? ((e[n.resultName] = r.value),
                                  (e.next = n.nextLoc),
                                  "return" !== e.method && ((e.method = "next"), (e.arg = t)),
                                  (e.delegate = null),
                                  f)
                                : r
                            : ((e.method = "throw"),
                              (e.arg = new TypeError("iterator result is not an object")),
                              (e.delegate = null),
                              f);
                    }
                    function $(n) {
                        var e = { tryLoc: n[0] };
                        1 in n && (e.catchLoc = n[1]),
                            2 in n && ((e.finallyLoc = n[2]), (e.afterLoc = n[3])),
                            this.tryEntries.push(e);
                    }
                    function T(n) {
                        var e = n.completion || {};
                        (e.type = "normal"), delete e.arg, (n.completion = e);
                    }
                    function C(n) {
                        (this.tryEntries = [{ tryLoc: "root" }]), n.forEach($, this), this.reset(!0);
                    }
                    function F(n) {
                        if (n) {
                            var e = n[a];
                            if (e) return e.call(n);
                            if ("function" == typeof n.next) return n;
                            if (!isNaN(n.length)) {
                                var i = -1,
                                    r = function e() {
                                        for (; ++i < n.length; )
                                            if (o.call(n, i)) return (e.value = n[i]), (e.done = !1), e;
                                        return (e.value = t), (e.done = !0), e;
                                    };
                                return (r.next = r);
                            }
                        }
                        return { next: N };
                    }
                    function N() {
                        return { value: t, done: !0 };
                    }
                })(
                    (function () {
                        return this;
                    })() || Function("return this")()
                );
            },
        },
        e = {};
    function t(i) {
        var o = e[i];
        if (void 0 !== o) return o.exports;
        var r = (e[i] = { id: i, exports: {} });
        return n[i](r, r.exports, t), r.exports;
    }
    (t.n = (n) => {
        var e = n && n.__esModule ? () => n.default : () => n;
        return t.d(e, { a: e }), e;
    }),
        (t.d = (n, e) => {
            for (var i in e) t.o(e, i) && !t.o(n, i) && Object.defineProperty(n, i, { enumerable: !0, get: e[i] });
        }),
        (t.o = (n, e) => Object.prototype.hasOwnProperty.call(n, e)),
        (t.nc = void 0),
        (() => {
            "use strict";
            var n = t(72),
                e = t.n(n),
                i = t(825),
                o = t.n(i),
                r = t(659),
                a = t.n(r),
                s = t(56),
                l = t.n(s),
                d = t(540),
                c = t.n(d),
                h = t(113),
                u = t.n(h),
                m = t(915),
                f = {};
            (f.styleTagTransform = u()),
                (f.setAttributes = l()),
                (f.insert = a().bind(null, "head")),
                (f.domAPI = o()),
                (f.insertStyleElement = c());
            e()(m.A, f);
            m.A && m.A.locals && m.A.locals;
            window.config.title || console.error(new Error("No title on window.config"));
            const p = Object.assign(
                {
                    loader: "unity",
                    maxRatio: 16 / 9,
                    minRatio: 9 / 16,
                    thumbnail:
                        "https://img.poki-cdn.com/cdn-cgi/image/quality=80,width=100,height=100,fit=cover,g=0.5x0.5,f=auto/a398cd4e645b76810031bd97f8697414.png",
                    numScreenshots: 4,
                    commentChangeTime: 5e3,
                    spinnerRemoveDelay: 1e3,
                    fullImageMaxWidth: 0.6,
                    fullImageMaxHeight: 0.7,
                    smallImageSizeOfFullImage: 0.8,
                    animationTargetSizeOfSmallImage: 0.5,
                    transitionDuration: 0.5,
                    slideshowInterval: 5,
                },
                window.config
            );
            t(446);
            let g, w, v, y;
            const b = "image";
            let x,
                S,
                k = 0,
                E = !1;
            const L = p.screenshotsVersion ? `?v${p.screenshotsVersion}` : "",
                I = window.location.pathname.substring(0, window.location.pathname.lastIndexOf("/")),
                $ =
                    window.location.hostname.endsWith("game-cdn.poki.com") ||
                    window.location.hostname.endsWith(".poki-gdn.com")
                        ? `/cdn-cgi/image/f=auto,quality=78${I}/`
                        : "";
            async function T() {
                const n = 1e3 * p.slideshowInterval,
                    e = y.querySelector("#slideshow-images .right"),
                    t = e.getAttribute("data-idx") | 0;
                if (e.getAttribute("fullImageLoaded"))
                    clearTimeout(window.slideShowMoveTransitionID),
                        clearTimeout(window.slideShowTimeoutID),
                        (window.slideShowTimeoutID = window.setTimeout(C, n));
                else {
                    const i = Date.now(),
                        o = await N(`${$}screenshots/${t + 1}.jpg${L}`);
                    (e.querySelector("img").src = o.src),
                        e.setAttribute("fullImageLoaded", !0),
                        clearTimeout(window.slideShowMoveTransitionID),
                        clearTimeout(window.slideShowTimeoutID);
                    const r = Date.now() - i;
                    r > n ? C() : (window.slideShowTimeoutID = window.setTimeout(C, n - r));
                }
            }
            function C() {
                if (E) return;
                let n = k + 1;
                n > p.numScreenshots - 1 && (n = 0),
                    (function (n) {
                        k = n | 0;
                        const e = k > 0 ? k - 1 : p.numScreenshots - 1,
                            t = k < p.numScreenshots - 1 ? k + 1 : 0;
                        y.querySelectorAll(".image").forEach((n) => {
                            n.className === `${b} left` && (n.className = `${b} fromLeft`),
                                n.className === `${b} right` && (n.className = `${b} fromRight`),
                                -1 === n.className.indexOf("inactive") && (n.className += " inactive");
                        });
                        y.querySelector(`[data-idx="${k}"]`).className = `${b} middle`;
                        y.querySelector(`[data-idx="${e}"]`).className = `${b} left`;
                        const i = y.querySelector(`[data-idx="${t}"]`);
                        (i.className = `${b} right`),
                            v.querySelectorAll(".bullet").forEach((n, e) => {
                                (n.className = "bullet"), e === k && (n.className += " active");
                            }),
                            (window.slideShowMoveTransitionID = window.setTimeout(() => {
                                y.querySelectorAll(".inactive").forEach((n) => {
                                    n.className = `${b} inactive fromRight`;
                                });
                            }, 1e3 * p.transitionDuration)),
                            T();
                    })(n);
            }
            function F() {
                const n = window.innerWidth / window.innerHeight;
                let e = (p.fullImageMaxWidth / x) * n,
                    t = p.fullImageMaxWidth;
                e > p.fullImageMaxHeight && ((e = p.fullImageMaxHeight), (t = (e * x) / n));
                const i = t * p.smallImageSizeOfFullImage,
                    o = 0.5 - t / 2,
                    r = t * p.animationTargetSizeOfSmallImage,
                    a = -2 * r,
                    s = 1 + r,
                    l = (1 - t) / 4 - t / 2,
                    d = 0.5 - 0.5 * t - (i + t) / 2,
                    c = 1 - (1 - t) / 4 - t / 2,
                    h = 0.5 + 0.5 * i,
                    u = Math.min(l, d),
                    m = Math.max(c, h);
                S.innerHTML = `\n\t\t#slideshow-images {\n\t\t\theight: ${100 * e}vh;\n\t\t}\n\t\t#slideshow-images .image {\n\t\t\ttransition-duration: ${p.transitionDuration}s;\n\t\t\twidth: ${100 * t}vw;\n\t\t\theight: ${100 * e}vh;\n\t\t}\n\t\t#slideshow-images .middle {\n\t\t\ttransform: translateX(${100 * o}vw);\n\t\t}\n\t\t#slideshow-images .left {\n\t\t\ttransform: translateX(${100 * u}vw) scale(${p.smallImageSizeOfFullImage});\n\t\t}\n\t\t#slideshow-images .right {\n\t\t\ttransform: translateX(${100 * m}vw) scale(${p.smallImageSizeOfFullImage});\n\t\t}\n\t\t#slideshow-images .inactive.fromLeft {\n\t\t\ttransform: translateX(${100 * a}vw) scale(${p.smallImageSizeOfFullImage * p.animationTargetSizeOfSmallImage});\n\t\t}\n\t\t#slideshow-images .inactive.fromRight {\n\t\t\ttransform: translateX(${100 * s}vw) scale(${p.smallImageSizeOfFullImage * p.animationTargetSizeOfSmallImage});\n\t\t}\n\t`;
            }
            function N(n) {
                return new Promise((e, t) => {
                    const i = new Image();
                    i.addEventListener("load", () => e(i)),
                        i.addEventListener("error", (n) => {
                            i.src.indexOf(".jpg") > 0 ? (i.src = i.src.replace(".jpg", ".png")) : t(n);
                        }),
                        (i.src = n);
                });
            }
            function B() {
                const n = document.createElement("div");
                return (n.className = b), n;
            }
            let M, A, R, D, O, j, P;
            function z() {
                const n = window.innerWidth,
                    e = window.innerHeight,
                    t = n / e;
                (M.style.width = `${n}px`),
                    (M.style.height = `${e}px`),
                    t > p.maxRatio
                        ? (M.style.width = e * p.maxRatio + "px")
                        : t < p.minRatio && (M.style.height = n / p.minRatio + "px");
                const i = M.getBoundingClientRect();
                (M.style.marginLeft = -0.5 * i.width + "px"), (M.style.marginTop = -0.5 * i.height + "px");
            }
            function _(n) {
                const e = 100 * n;
                (D.style.width = `${e}%`),
                    (O.innerHTML = (e | 0) + "%"),
                    p.fileSize && (O.innerHTML += ` of ${p.fileSize}MB`);
                const t = { percentageDone: n };
                PokiSDK.gameLoadingProgress(t),
                    n >= 1 &&
                        "done" !== R.className &&
                        ((R.className = "done"),
                        (document.getElementById("progress-comment").innerHTML = "Preparing game..."),
                        (document.getElementById("progress-spinner").style.display = "flex"),
                        P && clearTimeout(P));
            }
            (window.navigateNext = C),
                (window.removeSlideshowEventListeners = () => {
                    E = !0;
                });
            let G = 0;
            function H() {
                const n = p.loadingComments || ["Loading..."];
                n
                    ? ((j.innerHTML = n[G]), G++, G >= n.length && (G = 0), (P = setTimeout(H, p.commentChangeTime)))
                    : (j.innerHTML = "");
            }
            function q() {
                const n = document.createElement("script"),
                    e = "Build";
                (n.src = `${e}/${p.metadata.loader_filename}`),
                    (p.dataUrl = `${e}/${p.metadata.data_filename}`),
                    (p.frameworkUrl = `${e}/${p.metadata.framework_filename}`),
                    (p.codeUrl = `${e}/${p.metadata.code_filename}`),
                    (p.streamingAssetsUrl = "StreamingAssets"),
                    n.addEventListener("load", () => {
                        const n = document.querySelector("#game");
                        createUnityInstance(n, p, _)
                            .then((n) => {
                                (window.unityGame = n),
                                    (M.style.display = "block"),
                                    (A.style.display = "none"),
                                    z(),
                                    PokiSDK.gameLoadingFinished(),
                                    window.removeSlideshowEventListeners(),
                                    P && clearTimeout(P);
                            })
                            .catch((n) => {
                                console.error(n);
                            });
                    }),
                    document.body.appendChild(n),
                    PokiSDK.gameLoadingStart(),
                    p.fileSize &&
                        ((O.innerHTML += ` of ${p.fileSize}MB`),
                        (O.style.width = "12vh"),
                        (O.style.whiteSpace = "nowrap")),
                    H();
            }
            function U() {
                window.setTimeout(() => {
                    const n = document.getElementById("spinner");
                    n && n.parentNode && n.parentNode.removeChild(n);
                }, p.spinnerRemoveDelay);
            }
            !(function () {
                const n = document.createElement("div");
                n.setAttribute("id", "spinner"), (n.className = "spinner"), document.body.appendChild(n);
            })(),
                (window.onload = () => {
                    (M = document.getElementById("game-container")),
                        (A = document.getElementById("loader")),
                        (R = document.getElementById("progress-container")),
                        (D = document.getElementById("progress-fill")),
                        (O = document.getElementById("progress-amount")),
                        (j = document.getElementById("progress-comment")),
                        window.addEventListener("resize", z),
                        window.addEventListener("focus", z),
                        window.PokiSDK.init()
                            .then(() => {
                                window.pokiBridge
                                    ? window.unityGame.SendMessage(window.pokiBridge, "ready")
                                    : (window.pokiReady = !0);
                            })
                            .catch(() => {
                                window.pokiBridge
                                    ? window.unityGame.SendMessage(window.pokiBridge, "adblock")
                                    : (window.pokiAdBlock = !0),
                                    console.info("AdBlocker active");
                            }),
                        window.PokiSDK.setDebug(p && p.debug);
                    try {
                        (async function () {
                            let n;
                            (g = document.getElementById("slideshow")),
                                (w = document.getElementById("slideshow-top")),
                                (v = document.getElementById("slideshow-nav")),
                                (y = document.getElementById("slideshow-images")),
                                (w.className = "active");
                            try {
                                n = await N(`${$}screenshots/1-small.jpg${L}`);
                            } catch (e) {
                                n = await N(`${$}screenshots/1.jpg${L}`);
                            }
                            const e = B();
                            (e.className = `${b} middle`),
                                e.setAttribute("fullImageLoaded", !0),
                                e.setAttribute("data-idx", 0),
                                e.appendChild(n),
                                y.appendChild(e),
                                (g.className = "active"),
                                (x = n.width / n.height),
                                (S = document.createElement("style")),
                                F(),
                                document.body.appendChild(S),
                                window.addEventListener("resize", F);
                            for (let n = 0; n <= p.numScreenshots - 1; n++) {
                                const e = document.createElement("div");
                                (e.className = "bullet" + (0 === n ? " active" : "")),
                                    e.setAttribute("data-idx", n),
                                    v.appendChild(e);
                            }
                            const t = await N(`${$}screenshots/1.jpg${L}`);
                            e.querySelector("img").src = t.src;
                            const i = (n) => {
                                const e = B(),
                                    t = new Image();
                                (t.src = `${$}screenshots/${n + 1}-small.jpg${L}`),
                                    e.appendChild(t),
                                    e.setAttribute("data-idx", n),
                                    1 === n
                                        ? (e.className = `${b} right`)
                                        : n === p.numScreenshots - 1
                                          ? (e.className = `${b} left`)
                                          : (e.className = `${b} inactive`),
                                    y.appendChild(e);
                            };
                            for (let n = 1; n <= p.numScreenshots - 1; n++) i(n);
                            T();
                        })().then(() => {
                            U();
                        });
                    } catch (n) {
                        console.info("Slideshow loading error", n), U();
                    }
                    q();
                });
            t(612);
            function K(n) {
                const e = document.createElement("div");
                return (e.id = n), e;
            }
            const W = K("loader"),
                X = K("slideshow"),
                Y = K("slideshow-top"),
                V = document.createElement("img");
            (V.id = "thumbnail"), (V.alt = p.title), (V.title = p.title);
            let J = p.thumbnail;
            const Q = "";
            J.startsWith(Q) &&
                (J = `${Q}cdn-cgi/image/quality=78,width=40,height=40,fit=cover,g=0.5x0.5,f=auto/${J.substr(25)}`),
                (V.src = J);
            const Z = K("slideshow-top-container"),
                nn = K("game-title");
            nn.innerText = p.title;
            const en = K("progress-spinner");
            (en.innerHTML = '<div class="bounce0"></div><div class="bounce1"></div><div class="bounce2">'),
                en.setAttribute("class", "spinner");
            const tn = K("progress-container"),
                on = K("progress-bar"),
                rn = K("progress-fill");
            rn.style.width = "0%";
            const an = K("progress-amount");
            an.innerText = "0%";
            const sn = K("progress-comment");
            sn.innerText = "Loading";
            const ln = K("slideshow-images"),
                dn = K("slideshow-nav"),
                cn = K("game-container"),
                hn = document.createElement("canvas");
            hn.setAttribute("id", "game"),
                W.appendChild(X),
                X.appendChild(Y),
                X.appendChild(ln),
                X.appendChild(dn),
                Y.appendChild(V),
                Y.appendChild(Z),
                Z.appendChild(nn),
                Z.appendChild(en),
                Z.appendChild(tn),
                tn.appendChild(on),
                tn.appendChild(an),
                Z.appendChild(sn),
                on.appendChild(rn),
                cn.appendChild(hn),
                document.body.appendChild(W),
                document.body.appendChild(cn);
        })();
})();
